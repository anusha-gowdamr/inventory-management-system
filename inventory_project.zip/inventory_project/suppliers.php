<?php include 'db.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-5">
<h2>Suppliers</h2>
<a href="add_supplier.php" class="btn btn-success mb-3">+ Add</a>

<table class="table table-bordered">
<tr>
<th>ID</th><th>Name</th><th>Contact</th><th>Address</th><th>Action</th>
</tr>

<?php
$res = $conn->query("SELECT * FROM suppliers");
while($row = $res->fetch_assoc()){
echo "<tr>
<td>{$row['supplier_id']}</td>
<td>{$row['name']}</td>
<td>{$row['contact']}</td>
<td>{$row['address']}</td>
<td>
<a href='edit_supplier.php?id={$row['supplier_id']}' class='btn btn-warning btn-sm'>Edit</a>
<a href='delete_supplier.php?id={$row['supplier_id']}' class='btn btn-danger btn-sm'>Delete</a>
</td>
</tr>";
}
?>
</table>
</div>