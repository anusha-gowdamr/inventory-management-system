<?php
session_start();

if(isset($_POST['login'])){

    $user = $_POST['username'];
    $pass = $_POST['password'];

    if($user == "DBMS" && $pass == "IMS"){

        $_SESSION['user'] = $user;

        header("Location: index.php");

    } else {

        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <title>Inventory Login</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>

        body{
            background: linear-gradient(to right, #1d2671, #c33764);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box{
            width: 400px;
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 0px 20px rgba(0,0,0,0.3);
        }

        .login-title{
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .btn-login{
            width: 100%;
        }

    </style>

</head>

<body>

<div class="login-box">

    <h2 class="login-title">
        <i class="bi bi-box-seam"></i>
        Inventory Login
    </h2>

    <?php
    if(isset($error)){
        echo "<div class='alert alert-danger'>$error</div>";
    }
    ?>

    <form method="POST">

        <div class="mb-3">
            <label>Username</label>

            <input type="text"
            name="username"
            class="form-control"
            placeholder="Enter username"
            required>
        </div>

        <div class="mb-3">
            <label>Password</label>

            <input type="password"
            name="password"
            class="form-control"
            placeholder="Enter password"
            required>
        </div>

        <button type="submit"
        name="login"
        class="btn btn-primary btn-login">

            <i class="bi bi-box-arrow-in-right"></i>
            Login

        </button>

    </form>

</div>

</body>
</html>