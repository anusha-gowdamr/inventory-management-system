<?php include 'db.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-5">
<h2>🛒 Purchase</h2>

<form method="POST">

<label>Select Product</label>
<select name="product_id" class="form-control mb-3" required>
<option value="">-- Select Product --</option>
<?php
$res = $conn->query("SELECT * FROM products");
while($row = $res->fetch_assoc()){
    echo "<option value='{$row['product_id']}'>{$row['name']}</option>";
}
?>
</select>

<label>Select Supplier</label>
<select name="supplier_id" class="form-control mb-3" required>
<option value="">-- Select Supplier --</option>
<?php
$res = $conn->query("SELECT * FROM suppliers");
while($row = $res->fetch_assoc()){
    echo "<option value='{$row['supplier_id']}'>{$row['name']}</option>";
}
?>
</select>

<label>Quantity</label>
<input type="number" name="quantity" class="form-control mb-3" required>

<button name="submit" class="btn btn-success w-100">Add Purchase</button>

</form>

<?php
if(isset($_POST['submit'])){

    $product_id  = $_POST['product_id'];
    $supplier_id = $_POST['supplier_id'];
    $quantity    = $_POST['quantity'];

    // INSERT PURCHASE
    $sql = "INSERT INTO purchases (product_id, supplier_id, quantity, date)
            VALUES ('$product_id', '$supplier_id', '$quantity', NOW())";

    if($conn->query($sql)){
        
        // UPDATE STOCK
        $conn->query("UPDATE products 
                      SET quantity = quantity + $quantity 
                      WHERE product_id = $product_id");

        echo "<div class='alert alert-success mt-3'>✅ Purchase Added Successfully</div>";
    } else {
        echo "<div class='alert alert-danger mt-3'>❌ Error: ".$conn->error."</div>";
    }
}
?>
</div>