<?php include 'db.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-5">
<h2>Sales</h2>

<form method="POST">
    <select name="product_id" class="form-control mb-2" required>
        <option value="">-- Select Product --</option>

        <?php
        $res = $conn->query("SELECT * FROM products");
        while($row = $res->fetch_assoc()){
            echo "<option value='{$row['product_id']}'>{$row['name']}</option>";
        }
        ?>
    </select>

    <input type="number" name="qty" class="form-control mb-2" placeholder="Quantity" required>

    <button name="sell" class="btn btn-danger w-100">Sell Product</button>
</form>

<?php
if(isset($_POST['sell'])){
    $product_id = $_POST['product_id'];
    $qty = $_POST['qty'];

    // ✅ FIXED QUERY (this is where your error was)
    $check = $conn->query("SELECT quantity FROM products WHERE product_id = $product_id");
    $data = $check->fetch_assoc();

    if($data['quantity'] < $qty){
        echo "<div class='alert alert-danger mt-3'>Not enough stock!</div>";
    } else {
        // Insert sale
        $conn->query("INSERT INTO sales(product_id, quantity, date)
                      VALUES($product_id, $qty, NOW())");

        // Update stock
        $conn->query("UPDATE products 
                      SET quantity = quantity - $qty 
                      WHERE product_id = $product_id");

        echo "<div class='alert alert-success mt-3'>Sale successful!</div>";
    }
}
?>
</div>