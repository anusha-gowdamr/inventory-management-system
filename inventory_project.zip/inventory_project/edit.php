<?php
include 'db.php';

$id = $_GET['id'];

$result = $conn->query("SELECT * FROM products WHERE Product_id=$id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>

<h2>Edit Product</h2>

<form method="POST">
    Name: <input type="text" name="name" value="<?php echo $row['name']; ?>"><br><br>
    Category: <input type="text" name="category" value="<?php echo $row['category']; ?>"><br><br>
    Price: <input type="number" step="0.01" name="price" value="<?php echo $row['price']; ?>"><br><br>
    Quantity: <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>"><br><br>

    <input type="submit" name="update" value="Update Product">
</form>

<?php
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $sql = "UPDATE products 
            SET name='$name', category='$category', price='$price', quantity='$quantity'
            WHERE Product_id=$id";

    if($conn->query($sql)){
        header("Location: index.php");
    }
}
?>

</body>
</html>