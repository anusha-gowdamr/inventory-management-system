<?php
include 'db.php';

// COUNTS
$total_products = $conn->query("SELECT COUNT(*) as total FROM products")->fetch_assoc()['total'];

$total_suppliers = $conn->query("SELECT COUNT(*) as total FROM suppliers")->fetch_assoc()['total'];

$total_stock = $conn->query("SELECT SUM(quantity) as total FROM products")->fetch_assoc()['total'];

$low_stock = $conn->query("SELECT COUNT(*) as total FROM products WHERE quantity < 5")->fetch_assoc()['total'];

// CHART DATA
$product_query = $conn->query("SELECT name, quantity FROM products");

$product_names = [];
$product_qty = [];

while($row = $product_query->fetch_assoc()){
    $product_names[] = $row['name'];
    $product_qty[] = $row['quantity'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
body{
    display:flex;
    margin:0;
    font-family:Arial;
}

.sidebar{
    width:230px;
    height:100vh;
    background:#111827;
    padding:20px;
}

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    margin:15px 0;
    padding:10px;
    border-radius:8px;
    background:#1f2937;
}

.sidebar a:hover{
    background:#2563eb;
}

.content{
    flex:1;
    padding:20px;
}

.card-box{
    padding:20px;
    border-radius:10px;
    color:white;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3 style="color:white;">📦 Inventory</h3>

    <a href="dashboard.php">Dashboard</a>

    <a href="index.php">Products</a>

    <a href="suppliers.php">Suppliers</a>

    <a href="purchase.php">Purchase</a>

    <a href="purchase_history.php">Purchase History</a>

    <a href="sales.php">Sales</a>

    <a href="sales_history.php">Sales History</a>

    <a href="logout.php">Logout</a>
</div>

<!-- CONTENT -->
<div class="content">

<h1>Dashboard</h1>

<div class="row g-4">

    <div class="col-md-3">
        <div class="card-box bg-primary">
            <h5>Total Products</h5>
            <h2><?php echo $total_products; ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card-box bg-success">
            <h5>Total Suppliers</h5>
            <h2><?php echo $total_suppliers; ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card-box bg-warning">
            <h5>Total Stock</h5>
            <h2><?php echo $total_stock; ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card-box bg-danger">
            <h5>Low Stock ⚠</h5>
            <h2><?php echo $low_stock; ?></h2>
        </div>
    </div>

</div>

<!-- CHART -->
<div class="mt-5">

<h3>Product Stock</h3>

<canvas id="barChart"></canvas>

</div>

</div>

<script>

new Chart(document.getElementById('barChart'), {

    type: 'bar',

    data: {
        labels: <?php echo json_encode($product_names); ?>,

        datasets: [{
            label: 'Quantity',
            data: <?php echo json_encode($product_qty); ?>,
            borderWidth: 1
        }]
    }

});

</script>

</body>
</html>