<?php
session_start();
if(!isset($_SESSION['user'])){
    header("Location: login.php");
exit();
}
include 'db.php';
?>

<?php
// Total products
$totalProducts = $conn->query("SELECT COUNT(*) as total FROM products")->fetch_assoc();

// Low stock products
$lowStock = $conn->query("SELECT COUNT(*) as low FROM products WHERE quantity < 5")->fetch_assoc();

// Total quantity
$totalQty = $conn->query("SELECT SUM(quantity) as qty FROM products")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>

    <title>Inventory System</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial;
            background-color: #f4f6f9;
            text-align: center;
        }

        h2 {
            margin-top: 20px;
        }

        table {
            margin: auto;
            border-collapse: collapse;
            width: 70%;
            background: white;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        a.button {
            display: inline-block;
            padding: 10px 15px;
            margin: 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .delete {
            color: red;
            text-decoration: none;
        }
    </style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-dark bg-dark p-3">
    <div class="container-fluid">

        <span class="navbar-brand mb-0 h1">📦 Inventory System</span>

        <div>
            <a href="dashboard.php" class="btn btn-warning">Dashboard</a>
            <a href="index.php" class="btn btn-light">Products</a>
            <a href="suppliers.php" class="btn btn-info">Suppliers</a>
            <a href="purchase.php" class="btn btn-primary">Purchase</a>
            <a href="purchases.php" class="btn btn-secondary">Purchase History</a>
            <a href="sales.php" class="btn btn-success">Sales</a>
            <a href="sales_list.php" class="btn btn-danger">Sales History</a>
        </div>

    </div>
</nav>
<div class="container mt-4">

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow">
		
             <div class="container">
    <div class="card mt-4 p-3">
        <h5>Low Stock Items</h5>

        <?php
        include 'db.php';   // make sure this line is already in your file

        $result = $conn->query("SELECT * FROM products WHERE quantity < 5");

        while($row = $result->fetch_assoc()){
            echo "<p>{$row['name']} (Stock: {$row['quantity']})</p>";
        }
        ?>
    </div>
</div>
                <img src="images/dashboard.jpg" class="card-img-top">
                <div class="card-body text-center">
                    <h5>Dashboard</h5>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow">
                <img src="images/product.jpg" class="card-img-top">
                <div class="card-body text-center">
                    <h5>Products</h5>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow">
                <img src="images/sales.jpg" class="card-img-top">
                <div class="card-body text-center">
                    <h5>Sales</h5>
                </div>
            </div>
        </div>
    </div>
</div>


<h2>📦 Inventory System</h2>

<a href="logout.php" class="btn btn-danger mb-3">Logout</a>

<a href="add_product.php" class="button">+ Add Product</a>
<form method="GET" class="mb-3">
    <input type="text" name="search" class="form-control" placeholder="Search product...">
</form>
<?php
$count = $conn->query("SELECT COUNT(*) as total FROM products")->fetch_assoc();
?>
<h5>Total Products: <?php echo $count['total']; ?></h5>
<!-- ✅ ADD DASHBOARD HERE -->
<div class="container mt-4">
    <div class="row text-center">

        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>Total Products</h5>
                <h2><?php echo $totalProducts['total']; ?></h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>Low Stock</h5>
                <h2 style="color:red;">
                    <?php echo $lowStock['low']; ?>
                </h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card p-3 shadow">
                <h5>Total Quantity</h5>
                <h2><?php echo $totalQty['qty']; ?></h2>
            </div>
        </div>

    </div>
</div>
<br><br>
<!-- TABLE START -->
<div class="container mt-5">

<h2 class="mb-3">Product List</h2>

<table class="table table-bordered table-striped text-center">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php
if(isset($_GET['search'])){
    $search = $_GET['search'];
    $sql = "SELECT * FROM products WHERE name LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM products";
}
$result = $conn->query($sql);

while($row = $result->fetch_assoc()){

    $alert = ($row['quantity'] < 5) ? "<span style='color:red;'>🔴 Low</span>" : "";

    echo "<tr>
            <td>{$row['product_id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['category']}</td>
            <td>{$row['price']}</td>
            <td>{$row['quantity']} $alert</td>
            <td>
                <a href='edit.php?id={$row['product_id']}'>Edit</a> |
                <a href='delete.php?id={$row['product_id']}'>Delete</a>
            </td>
          </tr>";
}
   ?>

</table>

</body>
</html>