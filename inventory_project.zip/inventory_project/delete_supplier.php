<?php include 'db.php';
$conn->query("DELETE FROM suppliers WHERE supplier_id=".$_GET['id']);
header("Location: suppliers.php");
?>