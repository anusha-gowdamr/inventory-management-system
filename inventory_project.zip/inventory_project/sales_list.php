<?php include 'db.php'; ?>

<h2>Sales History</h2>

<table border="1">
<tr><th>ID</th><th>Product</th><th>Qty</th><th>Date</th></tr>

<?php
$res=$conn->query("SELECT s.*,p.name 
FROM sales s
JOIN products p ON s.product_id=p.product_id");

while($row=$res->fetch_assoc()){
echo "<tr>
<td>{$row['sale_id']}</td>
<td>{$row['name']}</td>
<td>{$row['quantity']}</td>
<td>{$row['date']}</td>
</tr>";
}
?>
</table>