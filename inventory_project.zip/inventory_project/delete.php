<?php
include 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM products WHERE Product_id=$id";

if($conn->query($sql)){
    header("Location: index.php");
}
?>