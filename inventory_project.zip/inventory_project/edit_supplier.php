<?php include 'db.php';
$id=$_GET['id'];
$data=$conn->query("SELECT * FROM suppliers WHERE supplier_id=$id")->fetch_assoc();
?>

<form method="POST">
<input type="text" name="name" value="<?= $data['name'] ?>">
<input type="text" name="contact" value="<?= $data['contact'] ?>">
<textarea name="address"><?= $data['address'] ?></textarea>

<button name="update">Update</button>
</form>

<?php
if(isset($_POST['update'])){
$conn->query("UPDATE suppliers SET 
name='{$_POST['name']}',
contact='{$_POST['contact']}',
address='{$_POST['address']}'
WHERE supplier_id=$id");

header("Location: suppliers.php");
}
?>