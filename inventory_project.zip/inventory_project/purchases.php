<?php include 'db.php'; ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-5">
<h2>Purchase History</h2>

<table class="table table-bordered table-striped">
<tr>
<th>ID</th>
<th>Product</th>
<th>Quantity</th>
<th>Date</th>
</tr>

<?php
$res = $conn->query("SELECT p.*, pr.name 
FROM purchases p
JOIN products pr ON p.product_id = pr.product_id");

while($row = $res->fetch_assoc()){
echo "<tr>
<td>{$row['purchase_id']}</td>
<td>{$row['name']}</td>
<td>{$row['quantity']}</td>
<td>{$row['date']}</td>
</tr>";
}
?>
</table>
</div>