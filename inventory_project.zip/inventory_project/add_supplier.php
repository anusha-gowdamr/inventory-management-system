<?php include 'db.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-5">
<h2>Add Supplier</h2>

<form method="POST">
    <input type="text" name="name" class="form-control mb-2" placeholder="Supplier Name" required>
    <input type="text" name="contact" class="form-control mb-2" placeholder="Contact">
    <textarea name="address" class="form-control mb-2" placeholder="Address"></textarea>

    <button name="submit" class="btn btn-primary">Add Supplier</button>
</form>

<?php
if(isset($_POST['submit'])){
    $conn->query("INSERT INTO suppliers(name,contact,address)
    VALUES('{$_POST['name']}','{$_POST['contact']}','{$_POST['address']}')");
    echo "<div class='alert alert-success mt-2'>Added!</div>";
}
?>
</div>